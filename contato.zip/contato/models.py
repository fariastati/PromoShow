from django.db import models

# Create your models here.

class Contato(models.Model):
	nome = models.CharField(max_length=100)
	email = models.EmailField()
	telefone = models.CharField(max_length=12)
	assunto = models.CharField(max_length=20)
	descricao = models.TextField()