from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.core.urlresolvers import reverse_lazy
from django.views.generic import ListView, CreateView, UpdateView, DeleteView

from apps.contato.forms import ContatoForm
from apps.contato.models import Contato

def index_contato(request):
	return HttpResponse("contato/indexContato.html")

def contato_view(request):
	if request.method == 'POST':
		form = ContatoForm(request.POST)
		if form.is_valid():
			form.save()
		return redirect('contato:contato_listar')
	else:
		form = ContatoForm()
	return render(resquest, 'contato/contato_form.html', {'form':form})

def contato_list(request):
	contato = Contato.objects.all().oredr_by('id')
	contexto = {'contato':contato}
	return render(request, 'contato/contato_list.html', contexto)


def contato_edit(request, id_usuario):
	contato = Contato.objects.get(id=id_contato)
	if request.method == 'GET':
		form = ContatoForm(instance=contato)
	else:
		form = ContatoForm(request.POST, instance=contato)
		if form.is_valid():
			form.save()
		return redirect('contato:contato_lista')
	return render(request, 'contato/contato_form.html', {'form':form})


def contato_delete(request, id_usuario):
	contato = Contato.objects.get(id=id_contato)
	if request.method == 'POTS':
		contato.delete()
		return redirect('contato:contato_editar')
	return render(request, 'contato/contato_delete.html', {'contato':contato})

class ContatoList(ListView):
	model = Contato
	template_name = 'contato/contato_list.html'

class ContatoCreate(CreateView):
	model = Contato
	form_class = ContatoForm
	template_name = 'contato/contato_form.html'
	sucess_url = reverse_lazy('contato/contato_listar')

class ContatoUpdate(UpdateView):
	model = Contato
	form_class = ContatoForm
	template_name = 'contato/contato_form.html'
	sucess_url = reverse_lazy('contato:contato_listar')

class ContatoDelete(DeleteView):
	model = Contato
	template_name = 'contato/contato_delete.html'
	sucess_url = reverse_lazy('contato:contato_listar')