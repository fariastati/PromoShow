from django.contrib import admin

from apps.contato.models import Contato

# Register your models here.
admin.site.register(Contato)