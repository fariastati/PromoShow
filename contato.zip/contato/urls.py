from django.conf.urls import url, include

from apps.contato.views import index_contato, contato_view, contato_list, contato_edit, contato_delete, ContatoList, ContatoCreate, ContatoUpdate, ContatoDelete

urlpatterns = [
    url(r'^$', index_contato, name='index_contato'),
    url(r'^novo$', ContatoCreate.as_view(), name='contato_criar'),
    url(r'^listar$', ContatoList.as_view(), name='contato_listar'),
    url(r'^editar/(?P<pk>\d+)/$', ContatoUpdate.as_view(), name='contato_editar'),
    url(r'^eliminar/(?P<pk>\d+)/$', ContatoDelete.as_view(), name='contato_eliminar'),
]