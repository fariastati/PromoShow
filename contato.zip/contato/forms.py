from django import forms

from apps.contato.models import Contato

class ContatoForm(forms.ModelForm):

	class Meta:
		model = Contato

		fields = [
			'nome',
			'email',
			'telefone',
			'assunto',
			'descricao',
		]
		labels = {
			'nome': 'nome',
			'email': 'email',
			'telefone': 'telefone',
			'assunto': 'assunto',
			'descricao': 'descricao',	

		}
		widgets = {
			'nome': forms.TextInput(attrs={'class':'form-control'}),
			'email': forms.TextInput(attrs={'class':'form-control'}),
			'telefone': forms.TextInput(attrs={'class':'form-control'}),
			'assunto': forms.TextInput(attrs={'class':'form-control'}),
			'descricao': forms.TextInput(attrs={'class':'form-control'}),
		}
