from django.apps import AppConfig


class ContatoConfig(AppConfig):
    name = 'contato'
